var searchData=
[
  ['n_5f',['n_',['../classfasttext_1_1Matrix.html#aeeddaea318709ea37127caae30194ff3',1,'fasttext::Matrix::n_()'],['../classfasttext_1_1QMatrix.html#a54082c819b9939e2d49fc0733a609cea',1,'fasttext::QMatrix::n_()']]],
  ['nbits_5f',['nbits_',['../classfasttext_1_1ProductQuantizer.html#ac44db00342a54cb05df9d0c136a8633c',1,'fasttext::ProductQuantizer']]],
  ['neg',['neg',['../classfasttext_1_1Args.html#a9f11afb2ec9b096e465149fb59153b30',1,'fasttext::Args']]],
  ['negative_5ftable_5fsize',['NEGATIVE_TABLE_SIZE',['../classfasttext_1_1Model.html#ab8e5d608cd0338d1dc2e2b2eeaed751c',1,'fasttext::Model']]],
  ['negatives',['negatives',['../classfasttext_1_1Model.html#a082187d7f01c243f296084878ea0e0f1',1,'fasttext::Model']]],
  ['negpos',['negpos',['../classfasttext_1_1Model.html#afaf1104f9e1c382c3eb30ca41311e84f',1,'fasttext::Model']]],
  ['nexamples_5f',['nexamples_',['../classfasttext_1_1Model.html#aeec9f08e7775bfcab322960fc80d7621',1,'fasttext::Model']]],
  ['niter_5f',['niter_',['../classfasttext_1_1ProductQuantizer.html#afa968d226983fbebfd2bb9d80bf6571f',1,'fasttext::ProductQuantizer']]],
  ['nlabels_5f',['nlabels_',['../classfasttext_1_1Dictionary.html#a875bb508d2a202b229e97e8295721f2c',1,'fasttext::Dictionary']]],
  ['norm_5fcodes_5f',['norm_codes_',['../classfasttext_1_1QMatrix.html#a17f22153d042c64052a3468faec70fce',1,'fasttext::QMatrix']]],
  ['npq_5f',['npq_',['../classfasttext_1_1QMatrix.html#a8203216a4cb2b721697f7dc2b509f25a',1,'fasttext::QMatrix']]],
  ['nsubq_5f',['nsubq_',['../classfasttext_1_1ProductQuantizer.html#a1e09b5c96869b0b4758348b976152309',1,'fasttext::ProductQuantizer']]],
  ['ntokens_5f',['ntokens_',['../classfasttext_1_1Dictionary.html#a9b92bc5d615b81df69f035448d329108',1,'fasttext::Dictionary']]],
  ['nwords_5f',['nwords_',['../classfasttext_1_1Dictionary.html#a534f33c9e34ed5185ea2a050d1140c62',1,'fasttext::Dictionary']]]
];
