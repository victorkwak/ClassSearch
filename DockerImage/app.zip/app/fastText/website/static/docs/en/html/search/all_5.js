var searchData=
[
  ['fasttext',['FastText',['../classfasttext_1_1FastText.html',1,'fasttext::FastText'],['../namespacefasttext.html',1,'fasttext'],['../classfasttext_1_1FastText.html#a3f1c81aafc45ad71824b332f5cb577d5',1,'fasttext::FastText::FastText()']]],
  ['fasttext_2ecc',['fasttext.cc',['../fasttext_8cc.html',1,'']]],
  ['fasttext_2eh',['fasttext.h',['../fasttext_8h.html',1,'']]],
  ['fasttext_5ffileformat_5fmagic_5fint32',['FASTTEXT_FILEFORMAT_MAGIC_INT32',['../fasttext_8h.html#af5de14588083ef853a2863c8d625ee24',1,'fasttext.h']]],
  ['fasttext_5fversion',['FASTTEXT_VERSION',['../fasttext_8h.html#a74036bd705019bb33643e90202bf343e',1,'fasttext.h']]],
  ['find',['find',['../classfasttext_1_1Dictionary.html#a5ee926831e9b71f7e966efdb40d1ce8f',1,'fasttext::Dictionary']]],
  ['findkbest',['findKBest',['../classfasttext_1_1Model.html#ad95e1ec209c506cf6ec1a5410d6f91d5',1,'fasttext::Model']]],
  ['findnn',['findNN',['../classfasttext_1_1FastText.html#a5c8825c522415d89478a54ecf28642c9',1,'fasttext::FastText']]],
  ['utils',['utils',['../namespacefasttext_1_1utils.html',1,'fasttext']]]
];
