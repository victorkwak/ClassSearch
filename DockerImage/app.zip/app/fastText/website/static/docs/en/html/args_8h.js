var args_8h =
[
    [ "Args", "classfasttext_1_1Args.html", "classfasttext_1_1Args" ],
    [ "loss_name", "args_8h.html#a1ba04862fd670674501ccacc936e1952", [
      [ "hs", "args_8h.html#a1ba04862fd670674501ccacc936e1952a789406d01073ca1782d86293dcfc0764", null ],
      [ "ns", "args_8h.html#a1ba04862fd670674501ccacc936e1952af01a37d157918910f2035b2af81ea4e1", null ],
      [ "softmax", "args_8h.html#a1ba04862fd670674501ccacc936e1952ace2f1fbd249d24aabc07ac4488ab5b8c", null ]
    ] ],
    [ "model_name", "args_8h.html#a349df214746a2ea0e5d7c26326b03d6f", [
      [ "cbow", "args_8h.html#a349df214746a2ea0e5d7c26326b03d6fae4709295b2cc44d67facf32b1099f1af", null ],
      [ "sg", "args_8h.html#a349df214746a2ea0e5d7c26326b03d6fa5dae429688af1c521ad87ac394192c6d", null ],
      [ "sup", "args_8h.html#a349df214746a2ea0e5d7c26326b03d6fa2eeecd72c567401e6988624b179d0b14", null ]
    ] ]
];