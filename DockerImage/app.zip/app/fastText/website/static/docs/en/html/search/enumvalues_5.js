var searchData=
[
  ['word',['word',['../namespacefasttext.html#a532eedeee97e8d66a96b519d165f4eb7ac47d187067c6cf953245f128b5fde62a',1,'fasttext']]]
];
