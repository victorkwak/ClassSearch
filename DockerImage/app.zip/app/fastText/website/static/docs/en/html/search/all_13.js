var searchData=
[
  ['uniform',['uniform',['../classfasttext_1_1Matrix.html#aef334e5d5a164b01c2b74960ffa3782d',1,'fasttext::Matrix']]],
  ['update',['update',['../classfasttext_1_1Model.html#ad92f524e3bf61598602c588408ca934b',1,'fasttext::Model']]],
  ['utils_2ecc',['utils.cc',['../utils_8cc.html',1,'']]],
  ['utils_2eh',['utils.h',['../utils_8h.html',1,'']]]
];
